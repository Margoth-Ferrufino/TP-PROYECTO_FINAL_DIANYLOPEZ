<?php

namespace Database\Factories;

use App\Models\nota;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class notaFactory extends Factory
{
    protected $model = nota::class;

    public function definition()
    {
        return [
            'created_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'updated_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'titulo' => $this->faker->sentence(),
            'contenido' => $this->faker->word(),
            'fecha' => $this->faker->date(),
        ];
    }
}
