@extends('plantilla');
@section('titulo', 'Detalles nota')
@section('inicio')

    <h2 class="text-center">Detalles de nota <br> {{$nota -> titulo}} </h2>
    <div class="col-md-12 d-flex justify-content-center">
        <div class="row">
            <!-- /.row -->
            <!-- /.col-md-12 -->
            <div class="card" style="width: 18rem;" xmlns="http://www.w3.org/1999/html">
                @if($nota)
                    <div class="card-body ">
                        <<h5 class="card-title d-flex justify-content-center">{{$nota->titulo}}</h5>
                        <p class="card-text" style="margin-bottom: 100px">{{$nota->contenido}}</p>
                        <p class="card-text">
                            @if($categorias && $categorias->count() > 0)
                                {{-- Itera sobre las categorías --}}
                                @foreach($categorias as $categoria)
                                    <span class="badge badge-dark">{{ $categoria->titulo }}</span>
                                @endforeach
                            @else
                                {{-- No hay categorías --}}
                                <span>Sin categoría</span>
                            @endif
                        </p>


                        <a href="{{ route('notas.index')}}" class="card-link">Ir al inicio</a>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal{{$nota->id}}">
                            Eliminar
                        </button>
                    </div>
                @else
                    <h5 class="card-title">Nota No Existe</h5>
                @endif

                <!-- Modal -->
                <div class="modal fade" id="modal{{$nota->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                ¿Está seguro que quiere eliminar la nota?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>

                                <form method="post" action="{{route('notas.destroy', $nota->id)}}">
                                    @csrf
                                    @method('delete')
                                    <input type="submit" class="btn btn-warning" value="Eliminar">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
