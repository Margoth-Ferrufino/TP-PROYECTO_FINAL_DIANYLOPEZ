<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class etiqueta extends Model
{
    use HasFactory;

    public function nota()
    {
        return $this->belongsToMany(nota::class, 'etiquetas_notas', 'notas_id', 'etiquetas_id');
    }
}
