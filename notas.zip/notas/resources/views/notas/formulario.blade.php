@extends('plantilla')
@section('titulo', 'Notas')
@section('inicio')

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="post" action="{{ isset($nota) ? route('notas.update', $nota->id) : route('notas.store')}}">
        @if(isset($nota))
            @method('PUT')
        @endif
        @csrf

        <h2 style="margin-bottom: 20px">{{isset($nota)? 'Editar Nota' : 'Agregar Nota'}}</h2>
        <div class="mb-3">
            <label for="titulo" class="form-label">Titulo</label>
            <input type="text" class="form-control" id="titulo" name="titulo" aria-describedby="emailHelp" placeholder="{{isset($nota)?$nota->titulo :  'Titulo de la nota'}}" value="{{isset($nota)?$nota->titulo :  old('titulo')}}">
        </div>
        <div class="mb-3">
            <label for="contenido" class="form-label">Contenido</label>
            <input type="text" class="form-control" id="contenido" name="contenido" placeholder="{{isset($nota)?$nota->contenido :  'Contenido de la nota'}}" value="{{isset($nota)?$nota->contenido :  old('contenido')}}">
        </div>

        <button type="submit" class="btn btn-primary">{{ isset($nota) ? 'Actualizar' : 'Agregar'}}</button>
    </form>
@endsection
