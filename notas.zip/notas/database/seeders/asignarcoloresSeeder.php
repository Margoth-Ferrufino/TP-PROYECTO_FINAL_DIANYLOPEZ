<?php

namespace Database\Seeders;

use App\Models\nota;
use Illuminate\Database\Seeder;

class asignarcoloresSeeder extends Seeder
{
    public function run()
    {
        $faker = faker::create();

        nota::chunk(100, function ($notas) use ($faker) {
            foreach ($notas as $nota) {
                $color = $faker->hexColor;
                $nota->update(['color' => $color]);
            }
        });
    }
}
