<?php

namespace Database\Seeders;

use App\Models\etiqueta;
use Illuminate\Database\Seeder;

class etiquetasSeeder extends Seeder
{
    public function run()
    {
        etiqueta::factory(20)->create();
    }
}
