<?php

namespace App\Http\Controllers;

use App\Models\nota;
use Illuminate\Http\Request;

class notasController extends Controller
{
    public function index()
    {
        $notas = nota::paginate(10);
        return view('notas.index')->with('notas', $notas);
    }

    public function create()
    {
        return view('notas.formulario');
    }

    public function store(Request $request)
    {


        $request->validate([
            'titulo' => 'required|string',
            'contenido' => 'nullable|regex:/^[\s\S]*$/',
        ]);

        $nota = new Nota();
        $nota->titulo = $request->input('titulo'); // Actualiza 'tituloNota' a 'titulo'
        $nota->contenido = $request->input('contenido');
        $nota->fecha = now();

        if ($nota->save()) {
            return redirect()->route('notas.index')->with('mensaje', 'Nota Agregada Correctamente');
        } else {
            return redirect()->route('notas.create')->with('mensaje', 'La nota no se pudo agregar');
        }

    }

    public function show($id)
    {
        $nota = Nota::find($id);
        $categorias = $nota->categorias; // Obtener las categorías asociadas a la nota
        return view('notas.show', compact('nota', 'categorias')); // Pasar la variable $categorias a la vista
    }



    public function edit($id)
    {
        $nota = nota::findOrFail($id);
        return view('notas.formulario')->with('nota', $nota);
    }

    public function update(Request $request, $id)
    {
        $nota = Nota::findOrFail($id);

        $request->validate([
            'titulo' => 'required|string',
            'contenido' => 'nullable|regex:/^[\s\S]*$/',
        ]);

        if ($request->filled('titulo')) {
            $nota->titulo = $request->input('titulo');
        }

        if ($request->filled('contenido')) {
            $nota->contenido = $request->input('contenido');
        }

        if ($nota->save()) {
            return redirect()->route('notas.index')->with('mensaje', 'Nota Actualizada Correctamente');
        } else {
            return redirect()->route('notas.update')->with('mensaje', 'La nota no se pudo actualizar');
        }

    }

    public function destroy($id)
    {
        if (nota::destroy($id) > 0){
            return redirect()->route('notas.index')-> with('mensaje', 'Borrado exitosamente');
        } else{
            return redirect()->route('notas.index')->with('mensaje', 'No se pudo borrar');
        }
    }
}
