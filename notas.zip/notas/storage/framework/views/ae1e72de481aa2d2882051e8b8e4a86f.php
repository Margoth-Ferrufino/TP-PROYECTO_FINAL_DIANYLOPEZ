<?php $__env->startSection('titulo', 'Notas'); ?>
<?php $__env->startSection('inicio'); ?>

    <h1 class="text-center">Lista de Notas </h1>
    <a href="<?php echo e(route('notas.create')); ?>" class="btn btn-dark d-flex justify-content-center align-items-center" tabindex="-1" role="button">Crear</a>

    <ul class="list-group">
        <?php $__empty_1 = true; $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item list-group-item-secondary d-flex justify-content-between align-items-center">
                <span style="border-color: <?php echo e($nota->etiquetas->isNotEmpty() ? $nota->etiquetas->first()->color : 'black'); ?>"><?php echo e($nota->titulo); ?></span>
                <div class="d-flex align-items-center">
                    <!-- Botones a la derecha -->
                    <div class="ml-auto">
                        <a href="<?php echo e(route('notas.edit', $nota)); ?>" class="btn btn-primary mr-1" tabindex="-1" role="button">Editar</a>
                        <a href="<?php echo e(route('notas.show', $nota)); ?>" class="btn btn-secondary" tabindex="-1" role="button">Ver</a>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="list-group-item">No hay notas disponibles</li>
        <?php endif; ?>
    </ul>



    <?php echo e($notas->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diany\OneDrive\Escritorio\MARGOTH FERRUFINO\UNAH I PAC 2024\Lenguaje de Programación IV\Laravel\notas\resources\views/notas/index.blade.php ENDPATH**/ ?>