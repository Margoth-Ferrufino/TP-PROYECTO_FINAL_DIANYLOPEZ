<?php

namespace Database\Factories;

use App\Models\etiqueta;
use App\Models\nota;
use Illuminate\Database\Eloquent\Factories\Factory;

class categorias_notasFactory extends Factory
{
    public function definition(): array
    {
        return [
            'nota_id'=>nota::factory(),
            'etiqueta_id'=>etiqueta::factory(),
        ];
    }
}
