@extends('plantilla')
@section('titulo', 'Notas')
@section('inicio')

    <h1 class="text-center">Lista de Notas </h1>
    <a href="{{route('notas.create')}}" class="btn btn-dark d-flex justify-content-center align-items-center" tabindex="-1" role="button">Crear</a>

    <ul class="list-group">
        @forelse($notas as $nota)
            <li class="list-group-item list-group-item-secondary d-flex justify-content-between align-items-center">
                <span style="border-color: {{$nota->etiquetas->isNotEmpty() ? $nota->etiquetas->first()->color : 'black'}}">{{$nota->titulo}}</span>
                <div class="d-flex align-items-center">
                    <!-- Botones a la derecha -->
                    <div class="ml-auto">
                        <a href="{{route('notas.edit', $nota)}}" class="btn btn-primary mr-1" tabindex="-1" role="button">Editar</a>
                        <a href="{{route('notas.show', $nota)}}" class="btn btn-secondary" tabindex="-1" role="button">Ver</a>
                    </div>
                </div>
            </li>
        @empty
            <li class="list-group-item">No hay notas disponibles</li>
        @endforelse
    </ul>



    {{$notas->links()}}
@endsection

