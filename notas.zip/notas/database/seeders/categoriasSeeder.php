<?php

namespace Database\Seeders;

use App\Models\categoria;
use Illuminate\Database\Seeder;

class categoriasSeeder extends Seeder
{
    public function run()
    {
        categoria::factory(20)->create();
    }
}
