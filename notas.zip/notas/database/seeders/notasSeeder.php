<?php

namespace Database\Seeders;

use App\Models\nota;
use Illuminate\Database\Seeder;

class notasSeeder extends Seeder
{
    public function run()
    {
        nota::factory(20)->create();
    }
}
