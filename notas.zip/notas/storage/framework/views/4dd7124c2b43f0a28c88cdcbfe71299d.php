<?php $__env->startSection('titulo', 'Notas'); ?>
<?php $__env->startSection('inicio'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(isset($nota) ? route('notas.update', $nota->id) : route('notas.store')); ?>">
        <?php if(isset($nota)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>

        <h2 style="margin-bottom: 20px"><?php echo e(isset($nota)? 'Editar Nota' : 'Agregar Nota'); ?></h2>
        <div class="mb-3">
            <label for="titulo" class="form-label">Titulo</label>
            <input type="text" class="form-control" id="titulo" name="titulo" aria-describedby="emailHelp" placeholder="<?php echo e(isset($nota)?$nota->titulo :  'Titulo de la nota'); ?>" value="<?php echo e(isset($nota)?$nota->titulo :  old('titulo')); ?>">
        </div>
        <div class="mb-3">
            <label for="contenido" class="form-label">Contenido</label>
            <input type="text" class="form-control" id="contenido" name="contenido" placeholder="<?php echo e(isset($nota)?$nota->contenido :  'Contenido de la nota'); ?>" value="<?php echo e(isset($nota)?$nota->contenido :  old('contenido')); ?>">
        </div>

        <button type="submit" class="btn btn-primary"><?php echo e(isset($nota) ? 'Actualizar' : 'Agregar'); ?></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diany\OneDrive\Escritorio\MARGOTH FERRUFINO\UNAH I PAC 2024\Lenguaje de Programación IV\Laravel\notas\resources\views/notas/formulario.blade.php ENDPATH**/ ?>