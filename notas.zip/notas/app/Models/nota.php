<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class nota extends Model
{
    use HasFactory;

    protected $fillable = ['titulo', 'contenido', 'color'];

    protected function casts()
    {
        return [
            'fecha' => 'date',
        ];
    }

    public function usuario()
    {
        return $this->belongsTo(User::class);
    }

    public function categorias()
    {
        return $this->belongsToMany(Categoria::class, 'categorias_notas', 'nota_id', 'categoria_id');
    }


    public function etiquetas()
    {
        return $this->belongsToMany(Etiqueta::class, 'etiquetas_notas', 'notas_id', 'etiquetas_id');
    }


}
